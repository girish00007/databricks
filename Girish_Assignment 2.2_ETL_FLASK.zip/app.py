from flask import Flask, render_template 
import sqlite3
import pandas as pd
import sqlalchemy
from sqlalchemy import create_engine

app = Flask(__name__)
engine = create_engine('sqlite:///Etl_database.db')

@app.route('/iris')
def indexiris():
   
    df_iris = pd.read_sql_table('iris_data', engine)
    iris = df_iris.to_html(classes='table table-bordered')
    return iris
@app.route('/tips')
def indextips():
    df1_tips = pd.read_sql_table('tips_data', engine)
    tips = df1_tips.to_html(classes="table table-bordered") 
    return tips
if __name__ == '__main__':
    app.run(debug=True)
