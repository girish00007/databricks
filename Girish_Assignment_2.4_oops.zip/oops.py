import pandas as pd
import matplotlib.pyplot as plt

class DataAnalyzer:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = None

    def load_data(self):
        if self.file_path.endswith('.csv'):
            self.data = pd.read_csv(self.file_path)
        elif self.file_path.endswith('.xlsx'):
            self.data = pd.read_excel(self.file_path, engine='openpyxl')
        else:
            raise ValueError("Unsupported file format. Only CSV and XLSX are supported.")

    def summarize_numeric_variables(self):
        if self.data is None:
            print("Data not loaded. Use 'load_data()' method first.")
            return

        numeric_columns = self.data.select_dtypes(include=[float, int]).columns
        summary = self.data[numeric_columns].describe()
        print(summary)

    def generate_categorical_bar_graph(self, variable_name):
        if self.data is None:
            print("Data not loaded. Use 'load_data()' method first.")
            return

        if variable_name not in self.data.columns:
            print(f"Variable '{variable_name}' not found in the dataset.")
            return

        categorical_counts = self.data[variable_name].value_counts()
        categorical_counts.plot(kind='bar')
        plt.xlabel(variable_name)
        plt.ylabel('Count')
        plt.title(f'Bar Graph for {variable_name}')
        plt.show()

    def plot_scatter_plot(self, x_variable, y_variable):
        if self.data is None:
            print("Data not loaded. Use 'load_data()' method first.")
            return

        if x_variable not in self.data.columns or y_variable not in self.data.columns:
            print("One or both specified variables not found in the dataset.")
            return

        plt.scatter(self.data[x_variable], self.data[y_variable])
        plt.xlabel(x_variable)
        plt.ylabel(y_variable)
        plt.title(f'Scatter Plot: {x_variable} vs {y_variable}')
        plt.show()
data=DataAnalyzer('train.csv')
data.load_data()
data.summarize_numeric_variables()
data.generate_categorical_bar_graph('Survived')
data.plot_scatter_plot('Age', 'Fare')


